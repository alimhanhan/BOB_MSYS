#ifndef FB3_1_H
#define FB3_1_H

extern int yylineno;
void yyerror(const char *s);

/* Abstract Syntax Tree nodes */
struct ast {
    int nodetype;
    struct ast *l;
    struct ast *r;
};

struct numval {
    int nodetype;  // type K for constants
    double number;
};

/* build an AST */
struct ast *newast(int nodetype, struct ast *l, struct ast *r);
struct ast *newnum(double d);

/* evaluate an AST */
double eval(struct ast *);

/* delete and free an AST */
void treefree(struct ast *);

#endif
