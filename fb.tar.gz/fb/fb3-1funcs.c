#include <stdio.h>
#include <stdlib.h>
#include "fb3-1.h"

/* new AST node */
struct ast *newast(int nodetype, struct ast *l, struct ast *r) {
    struct ast *a = malloc(sizeof(struct ast));
    if (!a) {
        yyerror("out of memory");
        exit(0);
    }
    a->nodetype = nodetype;
    a->l = l;
    a->r = r;
    return a;
}

/* new number node */
struct ast *newnum(double d) {
    struct numval *a = malloc(sizeof(struct numval));
    if (!a) {
        yyerror("out of memory");
        exit(0);
    }
    a->nodetype = 'K';
    a->number = d;
    return (struct ast *)a;
}

/* evaluate an AST */
double eval(struct ast *a) {
    double v;

    switch (a->nodetype) {
        case 'K': v = ((struct numval *)a)->number; break;

        case '+': v = eval(a->l) + eval(a->r); break;
        case '-': v = eval(a->l) - eval(a->r); break;
        case '*': v = eval(a->l) * eval(a->r); break;
        case '/': v = eval(a->l) / eval(a->r); break;

        default: printf("internal error: bad node %c\n", a->nodetype);
    }

    return v;
}

/* free an AST */
void treefree(struct ast *a) {
    switch (a->nodetype) {
        case '+':
        case '-':
        case '*':
        case '/':
            treefree(a->r);
        case 'K':
            treefree(a->l);
            break;

        case 'K':
            break;

        default: printf("internal error: free bad node %c\n", a->nodetype);
    }

    free(a);
}
